/*jslint node: true */
"use strict";
exports.INVE_URL = "";
exports.INVEValue = "1000000000000000000";
exports.headers = {'Content-Type': 'application/json'};