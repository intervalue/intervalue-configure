var config = {
    file_limit: '500MB'
};

module.exports = config;