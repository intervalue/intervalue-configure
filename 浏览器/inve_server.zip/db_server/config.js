exports.redis = {
    host: '127.0.0.1',
    port: '6379',
    password: '1234',
    db:0
};


exports.mysql_master = {
    host: '127.0.0.1',
    user: 'root',
    password: 'root',
    database:'inve',//主网数据
    connectionLimit: 10000,
    multipleStatements: true
};
